clear
find -size 0c -delete
#find . -type f -size 0 -delete
#find . -type f -empty -delete
echo "All zero-sized files successfully deleted"
