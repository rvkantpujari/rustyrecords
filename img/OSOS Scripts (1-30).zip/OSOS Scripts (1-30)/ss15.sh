clear
: '
Q. Write a shell script that displays all subdirectories in current working directory.
'
echo "Displays all subdirectories in current working directory:"
find ./ -type d
