
: '
Q. Write a shell script that displays all hidden files in current directory.
'
clear
ls -a
