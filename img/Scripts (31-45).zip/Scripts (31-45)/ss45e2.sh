cat stu.sh | egrep ":[7][0-9]|:80"
